import {db,json,clean,products,notifyDiscord} from '../lib/server.js';
export default async function handler(req,res){
 if(req.method!=='POST') {res.setHeader('Allow','POST');return json(res,405,{error:'Metoda niedozwolona'})}
 try{
  if(Number(req.headers['content-length']||0)>10000) return json(res,413,{error:'Zbyt duże zgłoszenie'});
  const input=req.body||{};
  if(input.website) return json(res,200,{ok:true}); // pułapka na automatyczny spam
  const id=clean(input.productId,50);const product=products.find(x=>x.id===id);
  const nick=clean(input.discordNick,40);const notes=clean(input.notes,500);
  if(!product) return json(res,400,{error:'Nieprawidłowy produkt'});
  if(!/^[a-zA-Z0-9_.]{2,32}$/.test(nick)) return json(res,400,{error:'Nick Discord: 2–32 znaki, litery, cyfry, _ lub kropka'});
  const {data,error}=await db().from('orders').insert({product_id:product.id,product_name:product.name,discord_nick:nick,notes,status:'new'}).select('id,product_name,discord_nick,notes,status,created_at').single();
  if(error) throw error;
  try {await notifyDiscord(data)}catch(e){console.error('Powiadomienie Discord nie zostało wysłane:',e.message)}
  return json(res,201,{ok:true,id:data.id});
 } catch(e){console.error('Tworzenie zamówienia:',e);return json(res,500,{error:'Nie udało się zapisać zamówienia. Spróbuj ponownie.'})}
}
