import {db,json,admin} from '../../lib/server.js';
const valid=['new','contacted','paid','completed','cancelled'];
export default async function handler(req,res){
 if(req.method!=='POST'){res.setHeader('Allow','POST');return json(res,405,{error:'Metoda niedozwolona'})}
 if(!admin(req,res))return;
 const {id,status}=req.body||{};
 if(typeof id!=='string'|| !/^[0-9a-f-]{36}$/i.test(id)||!valid.includes(status))return json(res,400,{error:'Niepoprawne dane'});
 try{
 const {data,error}=await db().from('orders').update({status}).eq('id',id).select('id,status').single();
 if(error)throw error;
 return json(res,200,{order:data});
 }catch(e){console.error('Zmiana statusu:',e);return json(res,500,{error:'Nie udało się zaktualizować'})}
}
