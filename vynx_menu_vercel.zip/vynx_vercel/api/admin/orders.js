import {db,json,admin} from '../../lib/server.js';
export default async function handler(req,res){
 if(req.method!=='GET'){res.setHeader('Allow','GET');return json(res,405,{error:'Metoda niedozwolona'})}
 if(!admin(req,res))return;
 try{
 const {data,error}=await db().from('orders').select('id,product_name,discord_nick,notes,status,created_at').order('created_at',{ascending:false}).limit(100);
 if(error)throw error;
 return json(res,200,{orders:data});
 }catch(e){console.error('Lista zamówień:',e);return json(res,500,{error:'Błąd pobierania zamówień'})}
}
